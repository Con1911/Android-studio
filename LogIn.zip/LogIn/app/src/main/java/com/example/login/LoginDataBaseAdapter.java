package com.example.login;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class LoginDataBaseAdapter {
    //Database version
    private static final int DATABASE_VERSION = 1;
    //Database name
    private static final String DATABASE_NAME = "Login.db";
    //Variable to hold the database instance
    private static SQLiteDatabase db;
    //Database open/upgrade helper
    private DataBaseHelper dataBaseHelper;

    //Constructor
    public LoginDataBaseAdapter(Context context){
        dataBaseHelper = new DataBaseHelper(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    //Method to open the database
    public LoginDataBaseAdapter open() throws SQLException{
        db = dataBaseHelper.getWritableDatabase();
        return this;
    }
    //Method to close the databasse
    public void close(){
        db.close();
    }
    //Method returns an instance of the database
    public SQLiteDatabase getDatabaseInstance(){
        return db;
    }
    //Insert username and password into the table
    public void insertEntry(String un, String pw){
        ContentValues newValues = new ContentValues();
        //Assign values for each row
        newValues.put("userName", un);
        newValues.put("userPassword", pw);
        //Insert the row into your table
        db.insert("User", null, newValues);
    }
    //Method to get the password of username
    public String getSingleEntry(String un){
        String getPassword = "";
        db = dataBaseHelper.getReadableDatabase();
        Cursor cursor = db.query("User", null, "userName=?", new String[]{un}, null, null, null);

        if(cursor.getCount() < 1) //Username Not Exist
        {
            cursor.close();
            return "NOT EXIST";
        }
        cursor.moveToFirst();
        int index = cursor.getColumnIndex("userPassword");
        getPassword = cursor.getString(index);
        //Closing connections
        cursor.close();
        db.close();
        //Returning password
        return getPassword;
    }
}
